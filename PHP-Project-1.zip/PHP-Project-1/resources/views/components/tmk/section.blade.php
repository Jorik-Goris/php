<section {{ $attributes->merge(['class' => 'p-4 bg-white border border-gray-300 rounded overflow-hidden shadow-md']) }}>
    {{ $slot }}
</section>
