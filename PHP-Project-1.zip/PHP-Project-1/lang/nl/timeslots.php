<?php

return [
    // edition specific translations
    'newTimeslot' => 'Nieuw tijdsblok',
    'addTimeslot' => 'Tijdsblok toevoegen',
    'start' => 'Start',
    'end' => 'Einde',
];
