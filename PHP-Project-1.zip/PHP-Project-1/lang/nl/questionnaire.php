<?php

return [
    // edition specific translations
    'questionnaire' => 'Vragenlijst',
    'url' => 'Link',
    'edition' => 'Editie',

    'createMessage' => 'De vragenlijst is aangemaakt.',
    'selectEdition' => 'Selecteer een editie',
    'deleteMessage' => 'De vragenlijst is verwijderd.',

    'noQuestionnaire' => 'Geen vragenlijst gevonden.',
];
