<?php

return [
    // edition specific translations
    'newTimeslot' => 'New timeslot',
    'addTimeslot' => 'Add timeslot',
    'start' => 'Start',
    'end' => 'End',
];
