<?php

return [
    // edition specific translations
    'questionnaire' => 'Questionnaire',
    'url' => 'URL',
    'edition' => 'Edition',

    'createMessage' => 'The questionnaire has been created.',
    'selectEdition' => 'Select an edition',
    'deleteMessage' => 'The questionnaire has been deleted.',

    'noQuestionnaire' => 'No questionnaire found.',
];
