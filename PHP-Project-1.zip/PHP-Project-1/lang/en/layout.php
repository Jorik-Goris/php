<?php

return [
    'en' => 'English',
    'nl' => 'Dutch',
];
