<?php

return [
    'Post Date' => 'Post Date',
    'Announcements' => 'Announcement|Announcements',
    'Not yet posted' => 'Not yet posted',
    'Title' => 'Title',
    'Content' => 'Content',
    'close' => 'Close',
    'view' => 'View',
    'click name' => "Click on the title for more information"

];
